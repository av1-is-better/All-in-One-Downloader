(function () {
    'use strict';

    angular.module('ariaNg').constant('ariaNgBuildConfiguration', {
        buildVersion: 'v1.3.10',
        buildCommit: 'ee48603'
    });
}());
