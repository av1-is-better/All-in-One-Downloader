import { useState, useEffect, useRef } from 'react'
import Logo from './assets/pixeldrain.webp'
import './App.css'
import { Routes, Route, Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { toast } from "react-toastify";
import { useSearchParams } from "react-router-dom";
import axios from 'axios';

function App() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [secret, setSecret] = useState("");
  const urlRef = useRef("");

  // show success notification
  const notifySuccess = (message) => {
    toast.success(message);
  };

  // show error notification
  const notifyError = (message) => {
    toast.error(message);
  };

  useEffect(()=>{
    // saving secret before removing url params
    setSecret(searchParams.get('secret'));

    // checking RPC secret passed via params or not
    if (searchParams.get('secret')){
      notifySuccess("Aria2 RPC Token Loaded");
    } else {
      notifyError("Aria2 RPC Secret Not Found!");
    }

    // removing url params
    setSearchParams({});
  },[])

  // formats a url and returns a list of url with different proxies
  // to bypass pixeldrain download limit
  const formatUrl = (url) => {
    const fileId = url.replace('https://pixeldrain.com/u/','').replaceAll('/','');
    const downloadUrl = `https://pixeldrain.com/api/file/${fileId}?download`;
    var links = [];

    // Generating 4 Random Urls To Boost Download Speed
    for (var x=1; x<5; x++){
      var randomNum = Math.floor(Math.random() * 20) + 1;
      var cloudflareProxy = `https://cdn${randomNum}.nuflix.workers.dev/?url=${downloadUrl}`;
      
      if (links.includes(cloudflareProxy)){
        x=x-1;
      }
      else {
        links.push(cloudflareProxy);
      }

      if (links.length == 4){
        break;
      }
    }
    
    // Returning a list of 4 urls
    return links;
  }

  // call aria2c RPC client to add new download task
  const addDownloadTask = async (downloadUrl, myButton, buttonName) => {
    // RPC Endpoint
    const RPC_SERVER_URL = window.location.protocol + '//' + window.location.host + '/app/rpc/jsonrpc';

    // Request Body Payload
    const payload = {
      jsonrpc: "2.0",
      method: "aria2.addUri",
      id: "add-url",
      params: [
        "token:"+secret,
        [...downloadUrl]
      ]
    };

    // API CALL
    try {
      const response = await axios.post(RPC_SERVER_URL, payload);
      notifySuccess("Download Added :-)")
    } catch (error) {
      notifyError("Operation Failed!")
    } finally {
      // reseting button and textbox
      myButton.textContent = buttonName
      myButton.disabled = false;
      urlRef.current.value = "";
    }

  }

  return (
    <>
      <Routes>

        <Route path="/" element={
          <>
            <img width={450} src={Logo} style={{borderRadius:"50px"}} />
            <p>Paste Your Link Here</p>
            <input ref={urlRef} type="text" 
              style={{fontSize:"14px", 
                      width:"500px",
                      fontFamily:"sans-serif",
                      padding:"10px",
                      backgroundColor:"white",
                      color:"black"
                    }}
              placeholder='https://pixeldrain.com/u/LSy1raYk'
            />
            <br />
            <button onClick={(e)=>{
              if (secret) {
                const myButton = e.target;
                const buttonName = myButton.textContent;
                
                myButton.textContent = 'Please Wait ...'
                myButton.disabled = true;

                const downloadUrl = urlRef.current.value;

                if (downloadUrl.startsWith('https://pixeldrain.com/u/')) {
                  addDownloadTask(formatUrl(downloadUrl), myButton, buttonName);
                }
                else {
                  downloadUrl ? notifyError("Invalid URL!") : notifyError("Please Enter URL!")
                  // reseting button and textbox
                  myButton.textContent = buttonName
                  myButton.disabled = false;
                  urlRef.current.value = "";
                }
              }
              else {
                notifyError("Aria2 RPC Secret Not Found!");
              }

            }} style={{marginLeft:"10px",marginTop:"20px"}}>Add to AriaNG</button>
          </>
        }/>

      </Routes>
      <ToastContainer />
    </>
  )
}

export default App
