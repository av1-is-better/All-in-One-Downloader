# Security Policy

## Supported Versions

The following versions are currently supported

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |
| 2.x.x   | :white_check_mark: |

## Reporting a Vulnerability

If you find a vulnerabilty, please report it to my personal mail id: bchaitanya15@gmail.com or to Nick nick@craig-wood.com. 
Your help is very much appreciated.
